#include <stdio.h>

extern void writescr(int ,int, char *);
extern void pmWriteScr(int,int,char *);
void clearscreen(int);
void writeln(char *);
extern void gdt_flush(int,int ,int ,int ,int,int);
 void pmWriteln(int,int);




/* Define GDT entry */

struct gdt_entry
{
	unsigned short limit_low;
	unsigned short base_low;    /* Base value goes to three different direction */
	unsigned char  base_middle;
	unsigned char  access;
	unsigned char  attributes;
	unsigned char  base_high;
} __attribute__((packed));


struct gdt_ptr
{
	unsigned short  limit;
	unsigned int base;
}__attribute__((packed));

extern void _linker(struct gdt_ptr *);

struct gdt_entry gdt[5]; /*GDT with 5 entry*/
struct gdt_ptr gp; /* GDT pointer */


/* Descriptor in the Global Descriptor Table */

void initGDTEntry(int index, unsigned long base , unsigned long limit, unsigned char access,
			unsigned char attributes)
{
	/*descriptor base address */
	gdt[index].base_low =(base& 0xFFFF);
	gdt[index].base_middle=(base>>16) & 0xFF;
	gdt[index].base_high=(base>>24) & 0xFF;
	
	/* Descriptor Limits */
	gdt[index].limit_low =(limit & 0xFFFF);
	gdt[index].attributes=((limit >>16)& 0x0F);
	
	gdt[index].attributes |=(attributes & 0xF0);
	gdt[index].access = access;
	
}

/* The GDT init Function */

void gdt_install()
{

	/* setup the GDT pointer and limit */
	
	gp.limit=(sizeof(struct gdt_entry)*5)-1;
	gp.base= (unsigned int)gdt;
	
	
	/* NULL descriptor */
	initGDTEntry(0,0,0,0,0);
	
	
	
	initGDTEntry(1,0,640*1024-1,0x9A,0x40);
	
	/* Data Segment */
	initGDTEntry(2,0,640*1024-1,0x92,0x40);
	
	/* stack segment*/
	initGDTEntry(3,0,640*1024-1,0x92,0x40);
	
	
	/* video segment */
	initGDTEntry(4,0xb8000,0xF9F,0x92,0x40); /* F9F hex value of 80*25*2-1*/
	

	
	
	/* Flush old GDT*/
	
	_linker((unsigned int)&gp);
	
	gdt_flush(8,16,24,16,16,16); /* 1x8 for CS
				   (2x8) for DS 
				   (3x8) for SS
				   4x8 for es */
	
	

	
}

int row_p =0;

void writeln (char *s)
{

	int col=1;
	writescr(row_p,col,s);
	col++;
	row_p++;
	
	
}

/* Clear the Screen */
void clearscreen(int line)

{
	int i=line;
	
	while(i >= 0)
	{	
		writescr(i,0,"                                                                                ");
		i++;
		
		if(i>25)
		return;
		
	}
}

/* This one used to fill the screen with *  in protected mood */

void pmWriteln(int row,int seg)
{
	int j=row;
	while (j>0)
	{
		pmWriteScr(j,seg,"********************************************************************************");	
		j++;
		
		if(j>25)
		return;
	}
}







int main(void)
{
	int line =0;
	unsigned int *s;
	int wCol=3;
	clearscreen(line);
	writeln("Initializing OS");
	writeln("Setting up OS descriptor...");
	
	gdt_install();
	
	pmWriteScr(wCol,32,"                  done");
	wCol++;
	
	pmWriteln(wCol,0);
	
	
	
	//clearscreen(0);
		
	
	
	while(1);	
	return 0;
} /*Main ends Here */



